<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Open source web server stack for Android</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, minimal-ui">
    <style>
      * {
        line-height: 1.5;
        margin: 0;
      }

      html {
        color: #888;
        font-family: sans-serif;
        text-align: center;
      }

      body {
        left: 50%;
        margin: -43px 0 0 -150px;
        position: absolute;
        top: 50%;
        width: 300px;
      }

      h1 {
        color: #555;
        font-size: 2em;
        font-weight: 400;
      }

      p {
        line-height: 1.2;
      }

      @media only screen and (max-width: 270px) {
        body {
          margin: 10px auto;
          position: static;
          width: 95%;
        }

        h1 {
          font-size: 1.5em;
        }
      }
    </style>
  </head>
  <body>
<?php
if (isset($_GET['phpinfo'])){
       phpinfo();
} else {
?>
    <h1>Hello World</h1>
    <p><b>Congratulations</b> You have just successfully install your very own Presonal Web Service for Android</p>
    <p>Start uploading your project to <code>/mnt/sdcard/htdocs</code></p>
    <p>Click <a href="?phpinfo">here</a> to see phpinfo</p>


    <h2>List of PHP extensions</h2>
    <ul class="">
<?php
    foreach(get_loaded_extensions() as $extName){
        printf('<li>%s</li>', $extName);
    }
}
?>
    </ul>

  </body>
</html>
